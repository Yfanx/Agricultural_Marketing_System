create definer = root@`%` trigger SC_U_Trigger
    before update
    on SC
    for each row
begin
    if new.Grade >= old.Grade*1.1 then
        insert into SC_U values(old.Sno, old.Cno, old.Grade, new.Grade);
    end if;
end;

